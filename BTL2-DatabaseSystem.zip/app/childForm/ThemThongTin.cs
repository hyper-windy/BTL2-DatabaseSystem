﻿using btl2.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace btl2.childForm
{
    public partial class ThemThongTin : Form
    {
        public ThemThongTin()
        {
            InitializeComponent();
        }

        private void btnAddBus_Click(object sender, EventArgs e)
        {
            object[] param = { txtMaBus.Text.Trim() };
            if(DataProvider.Instance.SetData("ThemTuyenXe", param))
            {
                txtMaChung.Text = txtMaBus.Text;
            }
        }

        private void btnAddTau_Click(object sender, EventArgs e)
        {
            object[] param = { txtSoHieuTau.Text.Trim(), txtTenTau.Text.Trim(), decimal.Parse(txtDonGia.Text.Trim()), txtMaTau.Text.Trim() };
            if(DataProvider.Instance.SetData("ThemTuyenTau", param))
            {
                txtMaChung.Text = txtMaTau.Text;
            }
            

        }

        private void btnAddChung_Click(object sender, EventArgs e)
        {
            object[] param = { txtMaChung.Text.Trim(), Convert.ToInt64(numSttChuyen.Value), txtMaGaTram.Text.Trim(), Convert.ToInt64(numSttDung.Value), dtpGhe.Value.TimeOfDay, dtpDi.Value.TimeOfDay };
            DataProvider.Instance.SetData("ThemTauXeGheGaTram", param);
        }
    }
}
