﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace btl2
{
    public partial class fInfo : Form
    {
        // Fields
        private Button currBtn;
        private Form activeForm;

        // Constructor
        public fInfo()
        {
            InitializeComponent();
        }

        // Btn setting
        private void activeBtn(object btnSender)
        {
            currBtn = (Button)btnSender;
            currBtn.FlatAppearance.BorderSize = 4;
        }

        private void disableBtn()
        {
            if(currBtn != null)
            {
                currBtn.FlatAppearance.BorderSize = 0;
            }
            
        }

        private void openChildForm(Form childForm)
        {
            if(activeForm != null)
            {
                activeForm.Close();
            }
            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            panelDesktop.Controls.Add(childForm);
            panelDesktop.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
            lblTitle.Text = childForm.Text;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            disableBtn();
            activeBtn(sender);
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (currBtn != (Button)sender)
            {
                disableBtn();
                activeBtn(sender);
                openChildForm(new childForm.PassengerInfo());
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (currBtn != (Button)sender)
            {
                disableBtn();
                activeBtn(sender);
                openChildForm(new childForm.ThemThongTin());
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (currBtn != (Button)sender)
            {
                disableBtn();
                activeBtn(sender);
                openChildForm(new childForm.ThongKe());
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
