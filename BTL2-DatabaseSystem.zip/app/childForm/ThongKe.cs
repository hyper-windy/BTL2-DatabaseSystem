﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using btl2.Model;
using MySql.Data.MySqlClient;

namespace btl2.childForm
{
    public partial class ThongKe : Form
    {
        public ThongKe()
        {
            InitializeComponent();
        }

        private void btnShow_Click(object sender, EventArgs e)
        {
            object[] param = { txbMa.Text.Trim(), dtpFrom.Value.ToString("dd/MM/yyyy"), dtpTo.Value.ToString("dd/MM/yyyy") };
            DataTable dt = DataProvider.Instance.GetData("ThongKeLuotNguoi", param);
            for(int i = 0; i < dt.Columns.Count; i++)
            {
                dgvThongKe.Columns[i].DataPropertyName = dt.Columns[i].ColumnName;
            }
            dgvThongKe.DataSource = dt;
        }
    }
}
