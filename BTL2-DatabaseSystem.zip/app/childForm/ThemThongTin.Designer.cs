﻿namespace btl2.childForm
{
    partial class ThemThongTin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label7 = new System.Windows.Forms.Label();
            this.txtMaBus = new System.Windows.Forms.TextBox();
            this.txtSoHieuTau = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtTenTau = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtDonGia = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtMaTau = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.btnAddBus = new System.Windows.Forms.Button();
            this.btnAddTau = new System.Windows.Forms.Button();
            this.pnlAddBus = new System.Windows.Forms.Panel();
            this.pnlAddTau = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtMaChung = new System.Windows.Forms.TextBox();
            this.txtMaGaTram = new System.Windows.Forms.TextBox();
            this.dtpGhe = new System.Windows.Forms.DateTimePicker();
            this.dtpDi = new System.Windows.Forms.DateTimePicker();
            this.numSttChuyen = new System.Windows.Forms.NumericUpDown();
            this.numSttDung = new System.Windows.Forms.NumericUpDown();
            this.btnAddChung = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.pnlAddGeGaTram = new System.Windows.Forms.Panel();
            this.pnlAddBus.SuspendLayout();
            this.pnlAddTau.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numSttChuyen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numSttDung)).BeginInit();
            this.pnlAddGeGaTram.SuspendLayout();
            this.SuspendLayout();
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Tahoma", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(53, 92);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(112, 29);
            this.label7.TabIndex = 1;
            this.label7.Text = "Mã tuyến";
            // 
            // txtMaBus
            // 
            this.txtMaBus.Font = new System.Drawing.Font("Tahoma", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaBus.Location = new System.Drawing.Point(232, 89);
            this.txtMaBus.Name = "txtMaBus";
            this.txtMaBus.Size = new System.Drawing.Size(184, 35);
            this.txtMaBus.TabIndex = 2;
            // 
            // txtSoHieuTau
            // 
            this.txtSoHieuTau.Font = new System.Drawing.Font("Tahoma", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSoHieuTau.Location = new System.Drawing.Point(232, 82);
            this.txtSoHieuTau.Name = "txtSoHieuTau";
            this.txtSoHieuTau.Size = new System.Drawing.Size(184, 40);
            this.txtSoHieuTau.TabIndex = 4;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Tahoma", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(41, 85);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(108, 34);
            this.label8.TabIndex = 3;
            this.label8.Text = "Số hiệu";
            // 
            // txtTenTau
            // 
            this.txtTenTau.Font = new System.Drawing.Font("Tahoma", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTenTau.Location = new System.Drawing.Point(232, 158);
            this.txtTenTau.Name = "txtTenTau";
            this.txtTenTau.Size = new System.Drawing.Size(184, 40);
            this.txtTenTau.TabIndex = 6;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Tahoma", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(42, 161);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(190, 34);
            this.label9.TabIndex = 5;
            this.label9.Text = "Tên tuyến tàu";
            // 
            // txtDonGia
            // 
            this.txtDonGia.Font = new System.Drawing.Font("Tahoma", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDonGia.Location = new System.Drawing.Point(232, 232);
            this.txtDonGia.Name = "txtDonGia";
            this.txtDonGia.Size = new System.Drawing.Size(184, 40);
            this.txtDonGia.TabIndex = 8;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Tahoma", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(42, 235);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(112, 34);
            this.label10.TabIndex = 7;
            this.label10.Text = "Đơn giá";
            // 
            // txtMaTau
            // 
            this.txtMaTau.Font = new System.Drawing.Font("Tahoma", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaTau.Location = new System.Drawing.Point(232, 302);
            this.txtMaTau.Name = "txtMaTau";
            this.txtMaTau.Size = new System.Drawing.Size(184, 40);
            this.txtMaTau.TabIndex = 10;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Tahoma", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(42, 305);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(131, 34);
            this.label11.TabIndex = 9;
            this.label11.Text = "Mã tuyến";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Tahoma", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(34, 27);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(283, 34);
            this.label12.TabIndex = 11;
            this.label12.Text = "Thêm tuyến xe bus";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Tahoma", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(34, 19);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(307, 34);
            this.label13.TabIndex = 12;
            this.label13.Text = "Thêm tuyến tàu điện";
            // 
            // btnAddBus
            // 
            this.btnAddBus.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddBus.Location = new System.Drawing.Point(355, 148);
            this.btnAddBus.Name = "btnAddBus";
            this.btnAddBus.Size = new System.Drawing.Size(90, 39);
            this.btnAddBus.TabIndex = 13;
            this.btnAddBus.Text = "Thêm";
            this.btnAddBus.UseVisualStyleBackColor = true;
            this.btnAddBus.Click += new System.EventHandler(this.btnAddBus_Click);
            // 
            // btnAddTau
            // 
            this.btnAddTau.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddTau.Location = new System.Drawing.Point(360, 373);
            this.btnAddTau.Name = "btnAddTau";
            this.btnAddTau.Size = new System.Drawing.Size(85, 38);
            this.btnAddTau.TabIndex = 14;
            this.btnAddTau.Text = "Thêm";
            this.btnAddTau.UseVisualStyleBackColor = true;
            this.btnAddTau.Click += new System.EventHandler(this.btnAddTau_Click);
            // 
            // pnlAddBus
            // 
            this.pnlAddBus.BackColor = System.Drawing.Color.Transparent;
            this.pnlAddBus.Controls.Add(this.label12);
            this.pnlAddBus.Controls.Add(this.label7);
            this.pnlAddBus.Controls.Add(this.btnAddBus);
            this.pnlAddBus.Controls.Add(this.txtMaBus);
            this.pnlAddBus.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlAddBus.Location = new System.Drawing.Point(0, 0);
            this.pnlAddBus.Name = "pnlAddBus";
            this.pnlAddBus.Size = new System.Drawing.Size(499, 210);
            this.pnlAddBus.TabIndex = 15;
            // 
            // pnlAddTau
            // 
            this.pnlAddTau.BackColor = System.Drawing.Color.Transparent;
            this.pnlAddTau.Controls.Add(this.label13);
            this.pnlAddTau.Controls.Add(this.label8);
            this.pnlAddTau.Controls.Add(this.btnAddTau);
            this.pnlAddTau.Controls.Add(this.txtSoHieuTau);
            this.pnlAddTau.Controls.Add(this.label9);
            this.pnlAddTau.Controls.Add(this.txtMaTau);
            this.pnlAddTau.Controls.Add(this.txtTenTau);
            this.pnlAddTau.Controls.Add(this.label11);
            this.pnlAddTau.Controls.Add(this.label10);
            this.pnlAddTau.Controls.Add(this.txtDonGia);
            this.pnlAddTau.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlAddTau.Location = new System.Drawing.Point(0, 209);
            this.pnlAddTau.Name = "pnlAddTau";
            this.pnlAddTau.Size = new System.Drawing.Size(499, 451);
            this.pnlAddTau.TabIndex = 16;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(53, 116);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(112, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "Mã tuyến";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(53, 197);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(197, 29);
            this.label2.TabIndex = 1;
            this.label2.Text = "Số thứ tự chuyến";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(53, 274);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(137, 29);
            this.label3.TabIndex = 2;
            this.label3.Text = "Mã ga trạm";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(53, 352);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(234, 29);
            this.label4.TabIndex = 3;
            this.label4.Text = "Số thứ tự trạm dừng";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Tahoma", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(53, 434);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(95, 29);
            this.label5.TabIndex = 4;
            this.label5.Text = "Giờ ghé";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Tahoma", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(53, 519);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(75, 29);
            this.label6.TabIndex = 5;
            this.label6.Text = "Giờ đi";
            // 
            // txtMaChung
            // 
            this.txtMaChung.Font = new System.Drawing.Font("Tahoma", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaChung.Location = new System.Drawing.Point(262, 113);
            this.txtMaChung.Name = "txtMaChung";
            this.txtMaChung.ReadOnly = true;
            this.txtMaChung.Size = new System.Drawing.Size(180, 35);
            this.txtMaChung.TabIndex = 6;
            // 
            // txtMaGaTram
            // 
            this.txtMaGaTram.Font = new System.Drawing.Font("Tahoma", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaGaTram.Location = new System.Drawing.Point(262, 271);
            this.txtMaGaTram.Name = "txtMaGaTram";
            this.txtMaGaTram.Size = new System.Drawing.Size(180, 35);
            this.txtMaGaTram.TabIndex = 8;
            // 
            // dtpGhe
            // 
            this.dtpGhe.CustomFormat = "HH:mm:ss";
            this.dtpGhe.Font = new System.Drawing.Font("Tahoma", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpGhe.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpGhe.Location = new System.Drawing.Point(262, 429);
            this.dtpGhe.Name = "dtpGhe";
            this.dtpGhe.ShowUpDown = true;
            this.dtpGhe.Size = new System.Drawing.Size(180, 35);
            this.dtpGhe.TabIndex = 10;
            // 
            // dtpDi
            // 
            this.dtpDi.CustomFormat = "HH:mm:ss";
            this.dtpDi.Font = new System.Drawing.Font("Tahoma", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpDi.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpDi.Location = new System.Drawing.Point(262, 514);
            this.dtpDi.Name = "dtpDi";
            this.dtpDi.ShowUpDown = true;
            this.dtpDi.Size = new System.Drawing.Size(180, 35);
            this.dtpDi.TabIndex = 11;
            // 
            // numSttChuyen
            // 
            this.numSttChuyen.Font = new System.Drawing.Font("Tahoma", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numSttChuyen.Location = new System.Drawing.Point(262, 195);
            this.numSttChuyen.Name = "numSttChuyen";
            this.numSttChuyen.Size = new System.Drawing.Size(90, 35);
            this.numSttChuyen.TabIndex = 12;
            // 
            // numSttDung
            // 
            this.numSttDung.Font = new System.Drawing.Font("Tahoma", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numSttDung.Location = new System.Drawing.Point(262, 350);
            this.numSttDung.Name = "numSttDung";
            this.numSttDung.Size = new System.Drawing.Size(90, 35);
            this.numSttDung.TabIndex = 13;
            // 
            // btnAddChung
            // 
            this.btnAddChung.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddChung.Location = new System.Drawing.Point(391, 582);
            this.btnAddChung.Name = "btnAddChung";
            this.btnAddChung.Size = new System.Drawing.Size(78, 38);
            this.btnAddChung.TabIndex = 15;
            this.btnAddChung.Text = "Thêm";
            this.btnAddChung.UseVisualStyleBackColor = true;
            this.btnAddChung.Click += new System.EventHandler(this.btnAddChung_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Tahoma", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(24, 27);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(308, 34);
            this.label14.TabIndex = 14;
            this.label14.Text = "Thêm lộ trình tàu/xe";
            // 
            // pnlAddGeGaTram
            // 
            this.pnlAddGeGaTram.BackColor = System.Drawing.Color.Transparent;
            this.pnlAddGeGaTram.Controls.Add(this.label14);
            this.pnlAddGeGaTram.Controls.Add(this.btnAddChung);
            this.pnlAddGeGaTram.Controls.Add(this.numSttDung);
            this.pnlAddGeGaTram.Controls.Add(this.numSttChuyen);
            this.pnlAddGeGaTram.Controls.Add(this.dtpDi);
            this.pnlAddGeGaTram.Controls.Add(this.dtpGhe);
            this.pnlAddGeGaTram.Controls.Add(this.txtMaGaTram);
            this.pnlAddGeGaTram.Controls.Add(this.txtMaChung);
            this.pnlAddGeGaTram.Controls.Add(this.label6);
            this.pnlAddGeGaTram.Controls.Add(this.label5);
            this.pnlAddGeGaTram.Controls.Add(this.label4);
            this.pnlAddGeGaTram.Controls.Add(this.label3);
            this.pnlAddGeGaTram.Controls.Add(this.label2);
            this.pnlAddGeGaTram.Controls.Add(this.label1);
            this.pnlAddGeGaTram.Dock = System.Windows.Forms.DockStyle.Right;
            this.pnlAddGeGaTram.Location = new System.Drawing.Point(499, 0);
            this.pnlAddGeGaTram.Name = "pnlAddGeGaTram";
            this.pnlAddGeGaTram.Size = new System.Drawing.Size(501, 660);
            this.pnlAddGeGaTram.TabIndex = 0;
            // 
            // ThemThongTin
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(1000, 660);
            this.Controls.Add(this.pnlAddTau);
            this.Controls.Add(this.pnlAddBus);
            this.Controls.Add(this.pnlAddGeGaTram);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ThemThongTin";
            this.Text = "THÊM TUYẾN TÀU/XE";
            this.pnlAddBus.ResumeLayout(false);
            this.pnlAddBus.PerformLayout();
            this.pnlAddTau.ResumeLayout(false);
            this.pnlAddTau.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numSttChuyen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numSttDung)).EndInit();
            this.pnlAddGeGaTram.ResumeLayout(false);
            this.pnlAddGeGaTram.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtMaBus;
        private System.Windows.Forms.TextBox txtSoHieuTau;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtTenTau;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtDonGia;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtMaTau;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button btnAddBus;
        private System.Windows.Forms.Button btnAddTau;
        private System.Windows.Forms.Panel pnlAddBus;
        private System.Windows.Forms.Panel pnlAddTau;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtMaChung;
        private System.Windows.Forms.TextBox txtMaGaTram;
        private System.Windows.Forms.DateTimePicker dtpGhe;
        private System.Windows.Forms.DateTimePicker dtpDi;
        private System.Windows.Forms.NumericUpDown numSttChuyen;
        private System.Windows.Forms.NumericUpDown numSttDung;
        private System.Windows.Forms.Button btnAddChung;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Panel pnlAddGeGaTram;
    }
}