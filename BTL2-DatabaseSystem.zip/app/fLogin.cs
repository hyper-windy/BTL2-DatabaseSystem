﻿using btl2.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace btl2
{
    public partial class fLogin : Form
    {
        public fLogin()
        {
            InitializeComponent();
        }

       
        private void btnLogin_Click(object sender, EventArgs e)
        {
            if(DataProvider.Instance.Login(txtUsr.Text, txtPass.Text))
            {
                fInfo f = new fInfo();
                this.Hide();
                f.ShowDialog();
                this.Show();
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
