use btl;
delete from chuyentauxe WHERE ma_tuyen = 'B006';
select * from tuyentau_xe;
select * from tuyenxebus;
SELECT * From tuyentaudien;
select * from chuyentauxe;
select * from ghega_tram;
select * from ga_tram;
insert into ghega_tram
	values("B006",6,"BT00001",2,"8:10","8:20" );