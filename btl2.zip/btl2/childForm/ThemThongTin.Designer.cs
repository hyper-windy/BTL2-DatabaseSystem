﻿namespace btl2.childForm
{
    partial class ThemThongTin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label14 = new System.Windows.Forms.Label();
            this.btnAddChung = new System.Windows.Forms.Button();
            this.numSttDung = new System.Windows.Forms.NumericUpDown();
            this.numSttChuyen = new System.Windows.Forms.NumericUpDown();
            this.dtpDi = new System.Windows.Forms.DateTimePicker();
            this.dtpGhe = new System.Windows.Forms.DateTimePicker();
            this.txtMaGaTram = new System.Windows.Forms.TextBox();
            this.txtMaChung = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.btnAddBus = new System.Windows.Forms.Button();
            this.txtMaBus = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.btnAddTau = new System.Windows.Forms.Button();
            this.txtSoHieuTau = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtMaTau = new System.Windows.Forms.TextBox();
            this.txtTenTau = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txtDonGia = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.numSttDung)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numSttChuyen)).BeginInit();
            this.SuspendLayout();
            // 
            // label14
            // 
            this.label14.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.SystemColors.Control;
            this.label14.Font = new System.Drawing.Font("Tahoma", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(495, 30);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(308, 34);
            this.label14.TabIndex = 29;
            this.label14.Text = "Thêm lộ trình tàu/xe";
            // 
            // btnAddChung
            // 
            this.btnAddChung.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAddChung.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddChung.Location = new System.Drawing.Point(867, 589);
            this.btnAddChung.Name = "btnAddChung";
            this.btnAddChung.Size = new System.Drawing.Size(78, 38);
            this.btnAddChung.TabIndex = 30;
            this.btnAddChung.Text = "Thêm";
            this.btnAddChung.UseVisualStyleBackColor = true;
            this.btnAddChung.Click += new System.EventHandler(this.btnAddChung_Click);
            // 
            // numSttDung
            // 
            this.numSttDung.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.numSttDung.Font = new System.Drawing.Font("Tahoma", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numSttDung.Location = new System.Drawing.Point(738, 344);
            this.numSttDung.Name = "numSttDung";
            this.numSttDung.Size = new System.Drawing.Size(90, 35);
            this.numSttDung.TabIndex = 28;
            // 
            // numSttChuyen
            // 
            this.numSttChuyen.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.numSttChuyen.Font = new System.Drawing.Font("Tahoma", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numSttChuyen.Location = new System.Drawing.Point(738, 189);
            this.numSttChuyen.Name = "numSttChuyen";
            this.numSttChuyen.Size = new System.Drawing.Size(90, 35);
            this.numSttChuyen.TabIndex = 27;
            // 
            // dtpDi
            // 
            this.dtpDi.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.dtpDi.CustomFormat = "HH:mm:ss";
            this.dtpDi.Font = new System.Drawing.Font("Tahoma", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpDi.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpDi.Location = new System.Drawing.Point(738, 508);
            this.dtpDi.Name = "dtpDi";
            this.dtpDi.ShowUpDown = true;
            this.dtpDi.Size = new System.Drawing.Size(180, 35);
            this.dtpDi.TabIndex = 26;
            // 
            // dtpGhe
            // 
            this.dtpGhe.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.dtpGhe.CustomFormat = "HH:mm:ss";
            this.dtpGhe.Font = new System.Drawing.Font("Tahoma", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpGhe.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpGhe.Location = new System.Drawing.Point(738, 423);
            this.dtpGhe.Name = "dtpGhe";
            this.dtpGhe.ShowUpDown = true;
            this.dtpGhe.Size = new System.Drawing.Size(180, 35);
            this.dtpGhe.TabIndex = 25;
            // 
            // txtMaGaTram
            // 
            this.txtMaGaTram.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtMaGaTram.Font = new System.Drawing.Font("Tahoma", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaGaTram.Location = new System.Drawing.Point(738, 265);
            this.txtMaGaTram.Name = "txtMaGaTram";
            this.txtMaGaTram.Size = new System.Drawing.Size(180, 35);
            this.txtMaGaTram.TabIndex = 24;
            // 
            // txtMaChung
            // 
            this.txtMaChung.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtMaChung.Font = new System.Drawing.Font("Tahoma", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaChung.Location = new System.Drawing.Point(738, 107);
            this.txtMaChung.Name = "txtMaChung";
            this.txtMaChung.ReadOnly = true;
            this.txtMaChung.Size = new System.Drawing.Size(180, 35);
            this.txtMaChung.TabIndex = 23;
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.SystemColors.Control;
            this.label6.Font = new System.Drawing.Font("Tahoma", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(512, 513);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(75, 29);
            this.label6.TabIndex = 22;
            this.label6.Text = "Giờ đi";
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.Control;
            this.label5.Font = new System.Drawing.Font("Tahoma", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(512, 428);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(95, 29);
            this.label5.TabIndex = 21;
            this.label5.Text = "Giờ ghé";
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.Control;
            this.label4.Font = new System.Drawing.Font("Tahoma", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(512, 346);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(234, 29);
            this.label4.TabIndex = 20;
            this.label4.Text = "Số thứ tự trạm dừng";
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.Control;
            this.label3.Font = new System.Drawing.Font("Tahoma", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(512, 268);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(137, 29);
            this.label3.TabIndex = 19;
            this.label3.Text = "Mã ga trạm";
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.Control;
            this.label2.Font = new System.Drawing.Font("Tahoma", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(512, 191);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(197, 29);
            this.label2.TabIndex = 18;
            this.label2.Text = "Số thứ tự chuyến";
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.Control;
            this.label1.Font = new System.Drawing.Font("Tahoma", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(512, 110);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(112, 29);
            this.label1.TabIndex = 17;
            this.label1.Text = "Mã tuyến";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.SystemColors.Control;
            this.label12.Font = new System.Drawing.Font("Tahoma", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(29, 30);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(283, 34);
            this.label12.TabIndex = 33;
            this.label12.Text = "Thêm tuyến xe bus";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.SystemColors.Control;
            this.label7.Font = new System.Drawing.Font("Tahoma", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(48, 104);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(112, 29);
            this.label7.TabIndex = 31;
            this.label7.Text = "Mã tuyến";
            // 
            // btnAddBus
            // 
            this.btnAddBus.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddBus.Location = new System.Drawing.Point(350, 161);
            this.btnAddBus.Name = "btnAddBus";
            this.btnAddBus.Size = new System.Drawing.Size(90, 39);
            this.btnAddBus.TabIndex = 34;
            this.btnAddBus.Text = "Thêm";
            this.btnAddBus.UseVisualStyleBackColor = true;
            this.btnAddBus.Click += new System.EventHandler(this.btnAddBus_Click);
            // 
            // txtMaBus
            // 
            this.txtMaBus.Font = new System.Drawing.Font("Tahoma", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaBus.Location = new System.Drawing.Point(227, 101);
            this.txtMaBus.Name = "txtMaBus";
            this.txtMaBus.Size = new System.Drawing.Size(184, 35);
            this.txtMaBus.TabIndex = 32;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.SystemColors.Control;
            this.label13.Font = new System.Drawing.Font("Tahoma", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(29, 231);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(307, 34);
            this.label13.TabIndex = 43;
            this.label13.Text = "Thêm tuyến tàu điện";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.SystemColors.Control;
            this.label8.Font = new System.Drawing.Font("Tahoma", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(36, 300);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(108, 34);
            this.label8.TabIndex = 35;
            this.label8.Text = "Số hiệu";
            // 
            // btnAddTau
            // 
            this.btnAddTau.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddTau.Location = new System.Drawing.Point(355, 589);
            this.btnAddTau.Name = "btnAddTau";
            this.btnAddTau.Size = new System.Drawing.Size(85, 38);
            this.btnAddTau.TabIndex = 44;
            this.btnAddTau.Text = "Thêm";
            this.btnAddTau.UseVisualStyleBackColor = true;
            this.btnAddTau.Click += new System.EventHandler(this.btnAddTau_Click);
            // 
            // txtSoHieuTau
            // 
            this.txtSoHieuTau.Font = new System.Drawing.Font("Tahoma", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSoHieuTau.Location = new System.Drawing.Point(227, 297);
            this.txtSoHieuTau.Name = "txtSoHieuTau";
            this.txtSoHieuTau.Size = new System.Drawing.Size(184, 40);
            this.txtSoHieuTau.TabIndex = 36;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.SystemColors.Control;
            this.label9.Font = new System.Drawing.Font("Tahoma", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(37, 374);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(190, 34);
            this.label9.TabIndex = 37;
            this.label9.Text = "Tên tuyến tàu";
            // 
            // txtMaTau
            // 
            this.txtMaTau.Font = new System.Drawing.Font("Tahoma", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaTau.Location = new System.Drawing.Point(227, 516);
            this.txtMaTau.Name = "txtMaTau";
            this.txtMaTau.Size = new System.Drawing.Size(184, 40);
            this.txtMaTau.TabIndex = 42;
            // 
            // txtTenTau
            // 
            this.txtTenTau.Font = new System.Drawing.Font("Tahoma", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTenTau.Location = new System.Drawing.Point(227, 371);
            this.txtTenTau.Name = "txtTenTau";
            this.txtTenTau.Size = new System.Drawing.Size(184, 40);
            this.txtTenTau.TabIndex = 38;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.SystemColors.Control;
            this.label11.Font = new System.Drawing.Font("Tahoma", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(37, 519);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(131, 34);
            this.label11.TabIndex = 41;
            this.label11.Text = "Mã tuyến";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.SystemColors.Control;
            this.label10.Font = new System.Drawing.Font("Tahoma", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(37, 448);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(112, 34);
            this.label10.TabIndex = 39;
            this.label10.Text = "Đơn giá";
            // 
            // txtDonGia
            // 
            this.txtDonGia.Font = new System.Drawing.Font("Tahoma", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDonGia.Location = new System.Drawing.Point(227, 445);
            this.txtDonGia.Name = "txtDonGia";
            this.txtDonGia.Size = new System.Drawing.Size(184, 40);
            this.txtDonGia.TabIndex = 40;
            // 
            // ThemThongTin
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(1000, 660);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.btnAddTau);
            this.Controls.Add(this.txtSoHieuTau);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txtMaTau);
            this.Controls.Add(this.txtTenTau);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.txtDonGia);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.btnAddBus);
            this.Controls.Add(this.txtMaBus);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.btnAddChung);
            this.Controls.Add(this.numSttDung);
            this.Controls.Add(this.numSttChuyen);
            this.Controls.Add(this.dtpDi);
            this.Controls.Add(this.dtpGhe);
            this.Controls.Add(this.txtMaGaTram);
            this.Controls.Add(this.txtMaChung);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MinimumSize = new System.Drawing.Size(1000, 660);
            this.Name = "ThemThongTin";
            this.Text = "THÊM TUYẾN TÀU/XE";
            ((System.ComponentModel.ISupportInitialize)(this.numSttDung)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numSttChuyen)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button btnAddChung;
        private System.Windows.Forms.NumericUpDown numSttDung;
        private System.Windows.Forms.NumericUpDown numSttChuyen;
        private System.Windows.Forms.DateTimePicker dtpDi;
        private System.Windows.Forms.DateTimePicker dtpGhe;
        private System.Windows.Forms.TextBox txtMaGaTram;
        private System.Windows.Forms.TextBox txtMaChung;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnAddBus;
        private System.Windows.Forms.TextBox txtMaBus;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnAddTau;
        private System.Windows.Forms.TextBox txtSoHieuTau;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtMaTau;
        private System.Windows.Forms.TextBox txtTenTau;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtDonGia;
    }
}