﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using btl2.Model;
using MySql.Data.MySqlClient;

namespace btl2.childForm
{
    public partial class PassengerInfo : Form
    {
        public PassengerInfo()
        {
            InitializeComponent();
        }


        private void PassengerInfo_Load(object sender, EventArgs e)
        {
            DataTable dt = DataProvider.Instance.GetData("ThongTinHanhKhach");
            for (int i = 0; i < dt.Columns.Count; i++)
            {
                dgvInfo.Columns[i].DataPropertyName = dt.Columns[i].ColumnName;
            }
            dgvInfo.DataSource = dt;
        }
    }
}
