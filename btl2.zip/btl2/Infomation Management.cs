﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace btl2
{
    public partial class fInfo : Form
    {
        // Fields
        private Button currBtn;
        private Form activeForm;
        bool isExits = true;

        // Constructor
        public fInfo()
        {
            InitializeComponent();
        }

        // Btn setting
        private void switchBtn(object sender)
        {
            if (currBtn != null)
            {
                currBtn.FlatAppearance.BorderSize = 0;
            }
            currBtn = (Button)sender;
            currBtn.FlatAppearance.BorderSize = 4;
        }

        private void openChildForm(Form childForm)
        {
            if(activeForm != null)
            {
                activeForm.Close();
            }
            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            panelDesktop.Controls.Add(childForm);
            panelDesktop.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
            lblTitle.Text = childForm.Text;
        }

        private void processBtn(object sender, Form childForm)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (currBtn != (Button)sender)
            {
                switchBtn(sender);
                openChildForm(new childForm.AboutUS());
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (currBtn != (Button)sender)
            {
                switchBtn(sender);
                openChildForm(new childForm.PassengerInfo());
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (currBtn != (Button)sender)
            {
                switchBtn(sender);
                openChildForm(new childForm.ThemThongTin());
            }       
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (currBtn != (Button)sender)
            {
                switchBtn(sender);
                openChildForm(new childForm.ThongKe());
            }
        }

        private void btnLogOut_Click(object sender, EventArgs e)
        {
            isExits = false;
            this.Close();
        }

        private void fInfo_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (isExits)
            {
                Application.Exit();
            }
        }

        private void fInfo_Load(object sender, EventArgs e)
        {
            switchBtn(button1);
            openChildForm(new childForm.AboutUS());
        }
    }
}
