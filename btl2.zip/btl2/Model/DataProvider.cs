﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace btl2.Model
{
    class DataProvider
    {
        private MySqlConnection connection;
        private string server;
        private string database;
        private string uid;
        private string password;
        private static DataProvider instance;

        public static DataProvider Instance
        {
            get { if (instance == null) instance = new DataProvider(); return instance; }
        }

        //Constructor
        public DataProvider()
        {
            Initialize();
        }

        //Initialize values
        private void Initialize()
        {
            server = "localhost";
            database = "btl";
            /*uid = "root";
            password = "19102001";
            string connectionString = "SERVER=" + server + ";" + "DATABASE=" +
            database + ";" + "UID=" + uid + ";" + "PASSWORD=" + password + ";";
            connection = new MySqlConnection(connectionString);*/
        }

        //open connection to database
        private bool OpenConnection()
        {
            try
            {
                connection.Open();
                return true;
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        //Close connection
        private bool CloseConnection()
        {
            try
            {
                connection.Close();
                return true;
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        public bool Login(string username, string password)
        {
            this.uid = username;
            this.password = password;
            string connectionString = "SERVER=" + server + ";" + "DATABASE=" +
            database + ";" + "UID=" + uid + ";" + "PASSWORD=" + password + ";";
            connection = new MySqlConnection(connectionString);
            try
            {
                connection.Open();
                connection.Close();
                MessageBox.Show("Đăng nhập thành công");
                return true;
            }
            catch
            {
                MessageBox.Show("Sai tài khoản/mật khẩu");
                return false;
            }
        }

        public DataTable GetData(string procedureName, object[] param = null)
        {
            DataTable dt = new DataTable();
            if (this.OpenConnection())
            {
                MySqlDataAdapter InfoData = new MySqlDataAdapter(procedureName, connection);
                InfoData.SelectCommand.CommandType = CommandType.StoredProcedure;
                string[] SqlParam = null;

                if(procedureName == "ThongKeLuotNguoi")
                {
                    SqlParam = new string[] { "matuyen", "fromDate", "toDate" };
                }

                if(SqlParam != null)
                {
                    int i = 0;
                    foreach (string val in SqlParam)
                    {
                        InfoData.SelectCommand.Parameters.AddWithValue(val, param[i]);
                        ++i;
                    }
                }

                try
                {
                    InfoData.Fill(dt);
                }
                catch (MySqlException ex)
                {
                    MessageBox.Show(ex.Message);
                }
                
                this.CloseConnection();
                
            }
            return dt;
        }

        public bool SetData(string procedureName, object[] param = null)
        {
            if (this.OpenConnection())
            {
                MySqlCommand cmd = new MySqlCommand(procedureName, connection);
                cmd.CommandType = CommandType.StoredProcedure;
                string[] SqlParam = null;

                if (procedureName == "ThemTauXeGheGaTram")
                {
                    SqlParam = new string[] { "Ma_tuyen", "stt", "MaGT","STT_dung","Gio_ghe","Gio_di" };
                }

                if (procedureName == "ThemTuyenXe")
                {
                    SqlParam = new string[] { "ma_tuyen" };
                }

                if (procedureName == "ThemTuyenTau")
                {
                    SqlParam = new string[] { "ma_tuyen_tau", "ten_tuyen_tau", "don_gia", "ma_tuyen" };
                }

                if (SqlParam != null)
                {
                    int i = 0;
                    foreach (string val in SqlParam)
                    {
                        cmd.Parameters.AddWithValue(val, param[i]);
                        ++i;
                    }
                }

                try
                {
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Thêm thành công!");
                    this.CloseConnection();
                    return true;
                }
                catch (MySqlException ex)
                {
                    MessageBox.Show(ex.Message);
                }
               
                this.CloseConnection();
                
            }
            return false;
        }


    }
}
